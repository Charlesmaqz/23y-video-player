package com.maqz.retroplayer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 1001;
    private LibVLC libVLC;
    private MediaPlayer mediaPlayer;
    private VLCVideoLayout videoLayout;
    private TextView statusText;
    private Button playPauseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
        initializePlayer();
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF101010);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView title = new TextView(this);
        title.setText("Retro Video Player");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        videoLayout = new VLCVideoLayout(this);
        root.addView(videoLayout, new LinearLayout.LayoutParams(-1, 0, 1f));

        statusText = new TextView(this);
        statusText.setText("Choose a video to start playing");
        statusText.setTextColor(0xFFDDDDDD);
        statusText.setPadding(0, dp(10), 0, dp(10));
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);

        Button chooseButton = new Button(this);
        chooseButton.setText("Choose video");
        chooseButton.setOnClickListener(v -> chooseVideo());
        controls.addView(chooseButton, new LinearLayout.LayoutParams(0, dp(52), 1f));

        playPauseButton = new Button(this);
        playPauseButton.setText("Play / Pause");
        playPauseButton.setOnClickListener(v -> togglePlayback());
        controls.addView(playPauseButton, new LinearLayout.LayoutParams(0, dp(52), 1f));

        Button stopButton = new Button(this);
        stopButton.setText("Stop");
        stopButton.setOnClickListener(v -> stopPlayback());
        controls.addView(stopButton, new LinearLayout.LayoutParams(0, dp(52), 1f));

        root.addView(controls, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void initializePlayer() {
        try {
            ArrayList<String> options = new ArrayList<>();
            options.add("--no-drop-late-frames");
            options.add("--no-skip-frames");
            libVLC = new LibVLC(this, options);
            mediaPlayer = new MediaPlayer(libVLC);
            mediaPlayer.attachViews(videoLayout, null, false, false);
        } catch (Exception e) {
            Toast.makeText(this, "Could not initialize video engine: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void chooseVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        try {
            startActivityForResult(intent, PICK_VIDEO);
        } catch (Exception e) {
            Toast.makeText(this, "No file picker is available", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
                // Some document providers do not offer persistable permissions.
            }
            playVideo(uri);
        }
    }

    private void playVideo(Uri uri) {
        if (libVLC == null || mediaPlayer == null) {
            Toast.makeText(this, "Video engine is not ready", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Media media = new Media(libVLC, uri);
            mediaPlayer.setMedia(media);
            media.release();
            mediaPlayer.play();
            statusText.setText("Playing: " + uri.getLastPathSegment());
        } catch (Exception e) {
            Toast.makeText(this, "Unable to play this video: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void togglePlayback() {
        if (mediaPlayer == null) return;
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        } else {
            mediaPlayer.play();
        }
    }

    private void stopPlayback() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            statusText.setText("Playback stopped");
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.detachViews();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (libVLC != null) {
            libVLC.release();
            libVLC = null;
        }
        super.onDestroy();
    }
}
